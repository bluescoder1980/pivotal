//
// $Workfile: NbhdPhaseData.cs$
// $Revision: 3$
// $Author: RYong$
// $Date: Wednesday, December 19, 2007 11:59:59 AM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    public static partial class NBHDPhaseData
    {
        public const string StatusOpen = "Open";
        public const string QueryReleasesToSynchronizeForCommunity = "Env: Releases To Synchronize For Community ?";
    }
}