//
// $Workfile: LoanData.cs$
// $Revision: 2$
// $Author: tlyne$
// $Date: Wednesday, December 19, 2007 11:24:08 AM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    public static partial class LoanData
    {
        public const string QueryLoansForQuote = "Env: Loans for Quote ?";
        public const string QueryOutOfSyncLoans = "Env: Out of sync Loans";
    }
}