//
// $Workfile: MI_NbhdPhaseData.cs$
// $Revision: 1$
// $Author: AB$
// $Date: December 18, 2007 12:07:00 AM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    internal static partial class MI_NBHDPhaseData
    {
        internal const string ExternalSourceIdField = "External_Release_Id";
    }
}