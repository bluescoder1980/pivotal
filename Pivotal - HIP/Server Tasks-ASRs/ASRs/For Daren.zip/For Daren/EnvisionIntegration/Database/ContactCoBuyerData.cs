//
// $Workfile: ContactCoBuyerData.cs$
// $Revision: 2$
// $Author: tlyne$
// $Date: Wednesday, December 19, 2007 11:24:08 AM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    public static partial class ContactCoBuyerData
    {
    }
}