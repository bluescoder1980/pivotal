//
// $Workfile: NbhdPhaseData.cs$
// $Revision: 2$
// $Author: tlyne$
// $Date: Thursday, January 18, 2007 2:01:05 PM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    internal static partial class NBHDPhaseData
    {
        internal const string QueryReleasesToSynchronizeForCommunity = "Env: Releases To Synchronize For Community ?";
    }
}