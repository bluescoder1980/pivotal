//
// $Workfile: ProductData.cs$
// $Revision: 5$
// $Author: jwang$
// $Date: Tuesday, April 10, 2007 2:05:02 PM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    internal static partial class ProductData
    {

        internal const string QueryAllOutOfSyncProducts = "Env: All out of sync Products";
    }
}