//
// $Workfile: LoanData.cs$
// $Revision: 3$
// $Author: tlyne$
// $Date: Monday, March 05, 2007 10:28:45 AM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    internal static partial class LoanData
    {
        internal const string QueryLoansForQuote = "Env: Loans for Quote ?";
        internal const string QueryOutOfSyncLoans = "Env: Out of sync Loans";
    }
}