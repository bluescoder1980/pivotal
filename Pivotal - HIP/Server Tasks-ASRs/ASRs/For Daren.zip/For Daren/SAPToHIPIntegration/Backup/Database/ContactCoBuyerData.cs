//
// $Workfile: ContactCoBuyerData.cs$
// $Revision: 1$
// $Author: tlyne$
// $Date: Thursday, February 01, 2007 1:30:24 PM$
//
// Copyright � Pivotal Corporation
//

namespace CdcSoftware.Pivotal.Applications.HomeBuilders.EF.Server
{
    internal static partial class ContactCoBuyerData
    {
    }
}